# EmailSorter

Then New Virsion = 0.3

- Sort Email from Email list 

- Write each email in txt file by it is company name For Ex. gmail.txt

- Fixed bugs 

- Never over write the result file 

- Check the correct path 

- Sort Emails in Secounds 

- Extract emails from text files 

# New Features 

- Fixed bugs 

- Remove Duplication emails

- Store emails in Database

- write each Domain by its extension name No matter was popular or not

- Extract emails from text files 


# Soon 
- Extract Emails from csv files 
- Choose specific domain to be Extracted 
- Email validator 


![EmailSortet](https://i.ibb.co/5MvPk89/Github3.jpg)
